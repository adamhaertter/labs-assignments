/* CSC111 Computer Science II
 * Lab 3 Modular Programming - lab3.h
 * Programmers: Adam Haertter and Yong Hang Lin
 * Professor: Dr. Lee
 * File Created: Sep 30, 2019
 * File Updated: Sep 30, 2019
 */

int lab3a(int);		//Initializes function from lab3a.c
int lab3b(int);		//Initializes function from lab3b.c
