/* CSC111 Computer Science II
 * Lab 3 Modular Programming - lab3b.c
 * Programmer: Yong Hang Lin & Adam Haertter
 * Professor: Dr. Lee
 * File Created: Sept 30, 2019
 * File Updated: Sept 30, 2019
 */

#include "lab3.h"

int lab3b(int i){
	int s;
	s = (i*(i+1))/2; //put integer in the equation
	return s;        //return the answer
}
